const express = require('express')
const cors = require('cors')
const app = express()
const port = 8000
const bodyParser = require('body-parser');
app.use(bodyParser.json());

const mongoClient = require('mongodb').MongoClient;
var db = null
const url = "mongodb+srv://admin:iRBafvoVODyIbRwv@cluster0.ht8ng.mongodb.net/test"
const dbName = "AnimalTracker_db"

app.listen(port, () => {
    console.log(`Listening on port ${port}`)
})

app.use(cors())

mongoClient.connect(url, (err,client) => {
    if(err != null) {
        throw err
    }
    db = client.db(dbName)
    console.log(`Connected to ${dbName}`)
})

app.get('/', (req, res) => {
    db.collection("data").find().toArray((err, data) => {
        if(err != null) {
            throw err
        }
        res.json(data)
    })
})

app.post('/', (req,res) => {
    db.collection("data").insertOne(req.body, (err,result) => {
        if(err != null) {
            throw err
        }
        console.log("added")
    })
})